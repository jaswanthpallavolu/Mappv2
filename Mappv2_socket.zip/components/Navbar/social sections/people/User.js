import axios from "axios";
import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import styles from "./user.module.css";
import { socket } from "../../../Layout";

function User({ uid, requser, setRequser, friends_list, setFriends_list }) {
  const [user, setUser] = useState();
  const [relation, setRelation] = useState(0);
  const [status,setStatus] = useState(false)
  const myuid = useSelector((state) => state.userAuth.user.uid);

  const fecthdetails = async () => {
    const details = await axios.get(
      `http://localhost:4500/friends/details?uid=${uid}`
    );
    if (details.data.friends.includes(myuid)) {
      // tick
      setRelation(1);
    } else if (details.data.send_requests.includes(myuid)) {
      // me accept
      setRelation(-2);
    } else if (details.data.receive_requests.includes(myuid)) {
      // decline
      setRelation(-1);
    }
    setUser(details.data);
  };

  const addUserRequest = () =>{
    console.log("hello addUserRequest")
    setRequser(requser=>[...requser,uid])
  }

  const removeUserRequest = () =>{
    console.log("hello removeUserRequest")
    setRequser(requser?.filter(i=>i!==uid))
  }

  const addUserFriend = () =>{
    setFriends_list(friends_list=>[...friends_list,uid])
  }

  const removeUserFriend = () =>{
    setFriends_list(friends_list?.filter(i=>i!==uid))
  }

  const userAction = async (action) => {
    if (action === "add") {
      socket.emit("send-friend-request",{senderId:myuid,receiverId:uid})
      addUserRequest()
      setRelation(-1);
    } else if (action === "accept") {
      socket.emit("friend-request-accepted",{senderId:myuid,receiverId:uid})
      addUserFriend()
      setRelation(1);
    } else if (action === "decline") {
      socket.emit("friend-request-declined",{senderId:myuid,receiverId:uid})
      removeUserRequest()
      setRelation(0);
    } else if (action === "remove") {
      socket.emit("friend-remove",{senderId:myuid,receiverId:uid})
      removeUserFriend()
      setRelation(0);
    }
  };

  //listeners
  useEffect(() => {
    socket.on("updated-online-users", (res) => {
      console.log({uid,res})
      if (res.users?.filter(i=>i["userId"]===uid).length===1){
          setStatus(true)
      }
    });

    socket.on("receive-friend-request",(res)=>{
      setRelation(-2)
      addUserRequest()
      console.log("request came from ",res.sender)
    })

    socket.on("notify-request-accepted",(res)=>{
      setRelation(1)
      addUserFriend()
      console.log("accept came from ",res.sender)
    })

    socket.on("notify-request-declined",(res)=>{
      setRelation(0)
      removeUserRequest()
      console.log("declined from ",res.sender)
    })

    socket.on("notify-friend-remove",(res)=>{
      setRelation(0)
      removeUserFriend()
      console.log("removed from ",res.sender)
    })

  }, [socket]);

  useEffect(() => {
    fecthdetails();
    socket.emit("get-online-users", myuid)
  }, [uid,myuid]);

  return (
    <div className={styles.one}>
      {user ? (
        <div className={styles.user_container}>
          <div
            className={`${styles.pic} ${styles.indi} ${
              (status || uid===myuid) ? styles.green : styles.grey
            }`}
          >
            {user["photo"] ? <img src={user["photo"]} className={styles.pic}/> : user.username[0]}
          </div>
          <div className={styles.info}>
            <div className={styles.name}>{user.username}</div>
            <div className={styles.status}>
              {(status || uid===myuid) ? "Online" : "Offline"}
            </div>
          </div>
          {uid !== myuid ? (
            <div className={styles.extend}>
              <div className={styles.cursor}>
                <i
                  className="fa-solid fa-message"
                  title="Message"
                  style={{ opacity: 0.7 }}
                ></i>
              </div>
              <div className={styles.cursor}>
                {relation === 0 ? (
                  <i
                    className="fa-solid fa-user-plus"
                    title="Add Friend"
                    onClick={() => userAction("add")}
                  ></i>
                ) : (
                  ""
                )}
                {relation === 1 ? (
                  <i
                    className="fa-solid fa-user-minus"
                    title="Friend"
                    onClick={() => userAction("remove")}
                  ></i>
                ) : (
                  ""
                )}
                {relation === -1 ? (
                  <i
                    className="fa-solid fa-user-xmark"
                    title="Cancel Request"
                    onClick={() => userAction("decline")}
                  ></i>
                ) : (
                  ""
                )}
                {relation === -2 ? (
                  <i
                    className="fa-solid fa-user-clock"
                    title="Accept Request"
                    onClick={() => userAction("accept")}
                  ></i>
                ) : (
                  ""
                )}
              </div>
            </div>
          ) : (
            ""
          )}
        </div>
      ) : (
        ""
      )}
    </div>
  );
}

export default User;
