export const userList = [
  {
    username: "giusgiugilgqwigdigqw iqw",
    status: true,
    uid: "123",
  },
  {
    username: "jaswanth",
    status: false,
    uid: "123",
  },
  {
    username: "hrithik",
    status: true,
    uid: "123",
  },
  {
    username: "raju",
    status: true,
    uid: "123",
  },
  {
    username: "pranai",
    status: false,
    uid: "123",
  },
  {
    username: "pradeep",
    status: true,
    uid: "123",
  },
  {
    username: "kranthi",
    status: true,
    uid: "123",
  },
  {
    username: "keerthi",
    status: true,
    uid: "123",
  },
  {
    username: "sarayu",
    status: true,
    uid: "123",
  },
];
