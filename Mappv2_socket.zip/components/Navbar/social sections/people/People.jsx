import React from "react"
import styles from "../iconsection.module.css"
import Groups from "./Groups"
export default function People() {
    return(
    <div className={styles.icon_section}>
      <Groups />
    </div>
    )
}
