import React from "react";
import styles from "../iconsection.module.css";
export default function MyList() {
  return <div className={styles.icon_section}>mylist</div>;
}
